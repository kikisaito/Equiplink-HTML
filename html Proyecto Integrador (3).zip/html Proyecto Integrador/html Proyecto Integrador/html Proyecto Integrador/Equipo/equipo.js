document.addEventListener('DOMContentLoaded', function () {
    // Selección de elementos del DOM
    const form = document.getElementById('equipmentForm');
    const requiredFields = form.querySelectorAll('[required]');
    const priceDisplayField = document.getElementById('price-display');
    const priceHiddenField = document.getElementById('price');

    // Muestra un mensaje de error para un campo
    const showError = (field, message) => {
        const inputGroup = field.parentElement;
        inputGroup.classList.add('error');
        const errorSpan = inputGroup.querySelector('.error-message');
        if (errorSpan) {
            errorSpan.textContent = message;
        }
    };

    // Oculta el mensaje de error de un campo
    const hideError = (field) => {
        const inputGroup = field.parentElement;
        inputGroup.classList.remove('error');
        const errorSpan = inputGroup.querySelector('.error-message');
        if (errorSpan) {
            errorSpan.textContent = '';
        }
    };

    // Gestión del envío del formulario
    form.addEventListener('submit', function (event) {
        event.preventDefault();
        let isFormValid = true;

        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                showError(field, 'Este campo es obligatorio.');
                isFormValid = false;
            } else {
                hideError(field);
            }
        });

        const priceValue = priceDisplayField.value.trim();
        if (priceValue) {
            if (!/^\d*\.?\d*$/.test(priceValue) || isNaN(parseFloat(priceValue))) {
                showError(priceDisplayField, 'Por favor, introduce un valor numérico.');
                isFormValid = false;
            } else {
                priceHiddenField.value = parseFloat(priceValue);
            }
        }
        
        if (isFormValid) {
            alert('Formulario validado con éxito. Precio a enviar: ' + priceHiddenField.value);
            // form.submit();
        }
    });

    // Limpieza de errores en tiempo real
    requiredFields.forEach(field => {
        field.addEventListener('input', () => {
            if (field.value.trim()) {
                hideError(field);
            }
        });
    });

    // Lógica para el campo de archivo
    const fileInput = document.getElementById('file');
    const fileNameSpan = document.querySelector('.file-name');

    if (fileInput && fileNameSpan) {
        fileInput.addEventListener('change', function() {
            if (this.files && this.files.length > 0) {
                fileNameSpan.textContent = this.files[0].name;
            } else {
                fileNameSpan.textContent = 'No se ha seleccionado ningún archivo';
            }
        });
    }
});