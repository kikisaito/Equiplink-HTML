document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('confirmarEliminarModal');
    const btnConfirmar = document.getElementById('btnConfirmarEliminar');
    let elementoAEliminar = null;

    // Función para abrir el modal
    window.abrirModalConfirmacion = (boton) => {
        // Guardamos la referencia al elemento padre (la tarjeta del producto)
        elementoAEliminar = boton.closest('.product-item');
        modal.style.display = 'flex';
    };

    // Función para cerrar el modal
    window.cerrarModalConfirmacion = () => {
        elementoAEliminar = null;
        modal.style.display = 'none';
    };

    // Evento para el botón de confirmación final
    btnConfirmar.addEventListener('click', () => {
        if (elementoAEliminar) {
            // Elimina el elemento del DOM
            elementoAEliminar.remove();
            
            // Aquí iría la lógica para llamar al servidor y eliminar el producto de la base de datos
            console.log('Producto eliminado.');

            // Cierra el modal después de eliminar
            cerrarModalConfirmacion();
        }
    });

    // Cierra el modal si se hace clic fuera de él
    window.addEventListener('click', (event) => {
        if (event.target === modal) {
            cerrarModalConfirmacion();
        }
    });
});