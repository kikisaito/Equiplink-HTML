const searchInput = document.getElementById('searchInput'); 
const perfiles = document.querySelectorAll('.perfil-empresa'); 

searchInput.addEventListener('input', (event) => {
  const searchTerm = event.target.value.toLowerCase();

  perfiles.forEach(perfil => {
    const textoPerfil = perfil.textContent.toLowerCase();

    if (textoPerfil.includes(searchTerm)) {
      perfil.style.display = 'flex';
    } else {
      perfil.style.display = 'none';
    }
  });
});  