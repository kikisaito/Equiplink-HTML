function validarRegistro(event) {
  // Obtener valores de los campos
  let usuario = document.getElementById("usuario").value.trim();
  let tipoUsuario = document.getElementById("tipoUsuario").value;
  let correo = document.getElementById("correo").value.trim();
  let contrasena = document.getElementById("contrasena").value.trim();

  // Obtener elementos de error
  let errorUsuario = document.getElementById("errorUsuario");
  let errorTipoUsuario = document.getElementById("errorTipoUsuario");
  let errorCorreo = document.getElementById("errorCorreo");
  let errorContrasena = document.getElementById("errorContrasena");

  // Limpiar errores previos
  errorUsuario.textContent = "";
  errorTipoUsuario.textContent = "";
  errorCorreo.textContent = "";
  errorContrasena.textContent = "";

  let valido = true;

  // Validación de Usuario
  if (usuario === "") {
    errorUsuario.textContent = "*Campo vacío";
    valido = false;
  }

  if (tipoUsuario === "") {
    errorTipoUsuario.textContent = "*Debes seleccionar un tipo de usuario";
    valido = false;
  }

  // Validación de Correo
  if (correo === "") {
    errorCorreo.textContent = "*Campo vacío";
    valido = false;
  } else if (!validarEmail(correo)) { // Validación adicional de formato de correo
    errorCorreo.textContent = "*Formato de correo inválido";
    valido = false;
  }

  // Validación de Contraseña
  if (contrasena === "") {
    errorContrasena.textContent = "*Campo vacío";
    valido = false;
  }

  if (valido) {
    // Redireccionar según el tipo de usuario
    if (tipoUsuario === "compania") {
      window.location.href = "/html Proyecto Integrador/Vista Formulario/index.html";
    } else if (tipoUsuario === "comprador") {
      window.location.href = "/html Proyecto Integrador/catalogo/visUsuario.html";
    }
    // Si el formulario es válido pero no se redirige (por ejemplo, si tipoUsuario está vacío por alguna razón),
    // evitamos que el formulario se envíe de forma tradicional.
    event.preventDefault(); 
  } else {
    // Si el formulario no es válido, prevenimos el envío por defecto para mostrar los errores.
    event.preventDefault();
  }

  return valido; // Retorna `valido` para que el `onsubmit` sepa si continuar o no.
}

function validarEmail(email) {
  // Expresión regular simple para validar formato de email
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
}

function abrirRegistro() {
  document.getElementById("modalRegistro").style.display = "flex";
}

function cerrarRegistro() {
  document.getElementById("modalRegistro").style.display = "none";
  // Opcional: limpiar campos del formulario al cerrar el modal
  document.getElementById("registroForm").reset();
  // Limpiar mensajes de error al cerrar
  document.getElementById("errorUsuario").textContent = "";
  document.getElementById("errorTipoUsuario").textContent = "";
  document.getElementById("errorCorreo").textContent = "";
  document.getElementById("errorContrasena").textContent = "";
}

function irALogin() {
  console.log("Cambiando a Login...");
}