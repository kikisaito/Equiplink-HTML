// NUEVA LÓGICA: Esta función se llama desde el enlace "¿Ya tienes una cuenta? Inicia Sesión"
function cambiarAModalLogin() {
  cerrarRegistro(); // Cierra el modal de registro
  abrirLogin();     // Abre el modal de login
}

// --- LÓGICA DEL MODAL DE LOGIN ---
function abrirLogin() {
  const modalFondo = document.getElementById("modalFondo");
  if (modalFondo) {
    modalFondo.style.display = "flex"; // Muestra el modal de login
  } else {
    console.error("Error: No se encontró el elemento #modalFondo.");
  }
}



// Abre el modal de login
function abrirLogin() {
  document.getElementById("modalFondo").style.display = "flex";
}

// Cierra el modal de login
function cerrarLogin() {
  document.getElementById("modalFondo").style.display = "none";
}

// Valida el formulario de login
function validarLogin() {
  const correo = document.getElementById("correo").value.trim();
  const contrasena = document.getElementById("contrasena").value.trim();
  const errorCorreo = document.getElementById("errorCorreo");
  const errorContrasena = document.getElementById("errorContrasena");

  errorCorreo.textContent = "";
  errorContrasena.textContent = "";

  let valido = true;

  if (correo === "") {
    errorCorreo.textContent = "*Campo vacío";
    valido = false;
  }

  if (contrasena === "") {
    errorContrasena.textContent = "*Campo vacío";
    valido = false;
  }

  return valido;
}
