package org.example.models.dtos;

// DTO para crear o actualizar un tipo de equipo
public class TypeEquipmentDto {
    private String type;

    public TypeEquipmentDto() {}

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
}